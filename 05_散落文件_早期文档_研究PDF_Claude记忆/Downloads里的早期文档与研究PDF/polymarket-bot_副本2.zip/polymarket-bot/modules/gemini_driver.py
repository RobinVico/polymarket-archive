"""
Module B — Gemini Deep Research 浏览器自动化
使用 Playwright 操控 Chrome 网页版 Gemini
"""

import time
import logging
import re
from pathlib import Path

log = logging.getLogger("gemini")

# ── 常量 ──
GEMINI_URL = "https://gemini.google.com/app"
MAX_WAIT_SECONDS = 900  # Deep Research 最长等待15分钟
POLL_INTERVAL = 10      # 每10秒检查一次是否完成


class GeminiDriver:
    def __init__(self, chrome_user_data_dir: str):
        """
        chrome_user_data_dir: Chrome用户数据目录路径
        Mac 默认: ~/Library/Application Support/Google/Chrome
        """
        self.chrome_user_data = chrome_user_data_dir
        self.browser = None
        self.context = None

    def _ensure_browser(self):
        """启动或复用持久化浏览器"""
        if self.context:
            return

        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()

        # ── 关键：使用持久化上下文，继承Chrome登录状态 ──
        # 注意：不能和正在运行的Chrome同时使用同一个profile目录
        # 方案：使用一个专门的playwright profile目录
        profile_dir = str(Path.home() / ".polymarket-bot-chrome-profile")
        Path(profile_dir).mkdir(exist_ok=True)

        self.context = self._pw.chromium.launch_persistent_context(
            user_data_dir=profile_dir,
            headless=False,         # 必须有头模式，Gemini检测无头
            channel="chrome",       # 使用系统安装的Chrome
            viewport={"width": 1280, "height": 900},
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ],
            slow_mo=500,  # 每个操作间隔500ms，模拟人类
        )
        log.info("Playwright 浏览器已启动")

    def _first_time_login_check(self, page):
        """
        首次使用时，检查是否需要手动登录Google
        如果检测到登录页面，等待用户手动操作
        """
        time.sleep(3)
        current_url = page.url
        if "accounts.google.com" in current_url or "signin" in current_url:
            log.warning("⚠️  检测到Google登录页面！请在浏览器中手动登录。")
            log.warning("    登录完成后，脚本将自动继续。")
            # 等待直到URL变为Gemini
            page.wait_for_url("**/gemini.google.com/**", timeout=300000)  # 5分钟
            log.info("✅ 登录成功，继续执行")
            time.sleep(3)

    def run_deep_research(self, prompt: str) -> str:
        """
        完整流程：打开Gemini → 输入prompt → 触发Deep Research → 等待 → 抓取结果
        返回: 原始文本（成功）/ None（失败）
        """
        try:
            self._ensure_browser()
            page = self.context.new_page()
            page.goto(GEMINI_URL, wait_until="networkidle", timeout=30000)
            self._first_time_login_check(page)

            time.sleep(3)

            # ═══ Step 1: 找到输入框并输入prompt ═══
            log.info("定位输入框...")
            # Gemini的输入框选择器 — 可能需要根据实际页面调整
            input_selectors = [
                'div[contenteditable="true"]',
                'rich-textarea div[contenteditable="true"]',
                '.ql-editor',
                'textarea',
                '[aria-label*="prompt"]',
                '[aria-label*="Enter"]',
            ]

            input_el = None
            for selector in input_selectors:
                try:
                    el = page.wait_for_selector(selector, timeout=5000)
                    if el and el.is_visible():
                        input_el = el
                        log.info(f"找到输入框: {selector}")
                        break
                except:
                    continue

            if not input_el:
                log.error("无法找到Gemini输入框，请检查页面结构")
                page.screenshot(path="debug_no_input.png")
                page.close()
                return None

            # 清空并输入（用clipboard粘贴，速度快且稳定）
            input_el.click()
            time.sleep(0.5)
            page.keyboard.press("Meta+a")  # Mac: Cmd+A 全选
            time.sleep(0.2)

            # 分段粘贴长prompt（避免浏览器卡死）
            page.evaluate(f"""
                navigator.clipboard.writeText({repr(prompt)})
            """)
            page.keyboard.press("Meta+v")  # Cmd+V 粘贴
            time.sleep(1)

            # ═══ Step 2: 尝试触发 Deep Research ═══
            log.info("尝试触发 Deep Research...")
            deep_research_triggered = False

            # 方法1: 找Deep Research按钮/选项
            dr_selectors = [
                'button:has-text("Deep Research")',
                '[aria-label*="Deep Research"]',
                'text=Deep Research',
                'button:has-text("深度研究")',  # 中文界面
            ]

            for selector in dr_selectors:
                try:
                    btn = page.wait_for_selector(selector, timeout=3000)
                    if btn and btn.is_visible():
                        btn.click()
                        deep_research_triggered = True
                        log.info(f"Deep Research 已触发 (via {selector})")
                        time.sleep(2)
                        break
                except:
                    continue

            if not deep_research_triggered:
                # 方法2: 如果找不到Deep Research按钮，可能需要先点模型选择器
                log.warning("未找到Deep Research按钮，尝试直接发送（降级为普通回复）")
                # 直接按Enter发送
                page.keyboard.press("Enter")
                time.sleep(2)

            # 如果触发了Deep Research，可能还需要确认
            try:
                # 有些版本需要点击"开始研究"之类的确认按钮
                confirm_selectors = [
                    'button:has-text("Start")',
                    'button:has-text("开始")',
                    'button:has-text("Research")',
                    'button:has-text("确认")',
                ]
                for sel in confirm_selectors:
                    try:
                        btn = page.wait_for_selector(sel, timeout=3000)
                        if btn and btn.is_visible():
                            btn.click()
                            log.info(f"确认研究: {sel}")
                            break
                    except:
                        continue
            except:
                pass

            # ═══ Step 3: 等待生成完成 ═══
            log.info(f"等待Gemini响应（最长{MAX_WAIT_SECONDS}秒）...")
            start_time = time.time()
            completed = False

            while time.time() - start_time < MAX_WAIT_SECONDS:
                time.sleep(POLL_INTERVAL)
                elapsed = int(time.time() - start_time)

                # 检查是否还在生成中
                # 方法：检测"停止生成"按钮是否存在
                still_generating = False
                stop_selectors = [
                    'button:has-text("Stop")',
                    'button:has-text("停止")',
                    '[aria-label*="Stop"]',
                    '.loading-indicator',
                    '[data-test-id="stop-button"]',
                ]
                for sel in stop_selectors:
                    try:
                        el = page.query_selector(sel)
                        if el and el.is_visible():
                            still_generating = True
                            break
                    except:
                        continue

                if still_generating:
                    log.info(f"  ... 仍在生成中 ({elapsed}s)")
                    continue

                # 不再生成，检查是否有输出内容
                time.sleep(3)  # 额外等待渲染
                completed = True
                break

            if not completed:
                log.warning(f"Gemini 响应超时 ({MAX_WAIT_SECONDS}s)")
                page.screenshot(path="debug_timeout.png")
                page.close()
                return None

            # ═══ Step 4: 抓取输出文本 ═══
            log.info("抓取Gemini输出...")
            output_text = self._extract_response(page)

            if not output_text or len(output_text) < 100:
                log.warning("输出文本过短或为空")
                page.screenshot(path="debug_short_output.png")
                page.close()
                return None

            log.info(f"成功抓取 {len(output_text)} 字符")
            page.close()
            return output_text

        except Exception as e:
            log.exception(f"Gemini自动化出错: {e}")
            try:
                page.screenshot(path="debug_error.png")
                page.close()
            except:
                pass
            return None

    def _extract_response(self, page) -> str:
        """
        从Gemini页面提取AI回复文本
        尝试多种选择器，适配不同版本的Gemini UI
        """
        response_selectors = [
            # Gemini 回复气泡的常见选择器
            '.response-content',
            '.model-response-text',
            '[data-message-author-role="model"]',
            '.markdown-main-panel',
            'message-content',
            '.conversation-container .model-response',
        ]

        for selector in response_selectors:
            try:
                elements = page.query_selector_all(selector)
                if elements:
                    # 取最后一个（最新的回复）
                    last_el = elements[-1]
                    text = last_el.inner_text()
                    if text and len(text) > 50:
                        return text.strip()
            except:
                continue

        # 兜底：尝试抓取页面上所有可见的大段文本
        try:
            all_text = page.evaluate("""
                () => {
                    const elements = document.querySelectorAll('div, p, span');
                    let longest = '';
                    for (const el of elements) {
                        const text = el.innerText || '';
                        if (text.length > longest.length && text.length > 200) {
                            longest = text;
                        }
                    }
                    return longest;
                }
            """)
            if all_text:
                return all_text.strip()
        except:
            pass

        return None

    def close(self):
        """清理资源"""
        try:
            if self.context:
                self.context.close()
            if hasattr(self, '_pw'):
                self._pw.stop()
        except:
            pass
