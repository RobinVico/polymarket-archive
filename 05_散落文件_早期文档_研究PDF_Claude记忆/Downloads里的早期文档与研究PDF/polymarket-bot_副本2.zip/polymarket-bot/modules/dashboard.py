"""
Flask Dashboard — 实时监控面板
http://localhost:5050
"""

from flask import Flask, render_template_string
from modules.db import get_recent_events, get_daily_spend, get_conn
from datetime import datetime


DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Polymarket Bot</title>
<meta http-equiv="refresh" content="60">
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600&family=Noto+Sans+SC:wght@300;400;600&display=swap');

  :root {
    --bg: #0a0a0f;
    --surface: #12121a;
    --border: #1e1e2e;
    --text: #c8c8d4;
    --text-dim: #666680;
    --accent: #22d68a;
    --red: #ef4444;
    --yellow: #eab308;
    --blue: #3b82f6;
  }

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    font-family: 'JetBrains Mono', 'Noto Sans SC', monospace;
    background: var(--bg);
    color: var(--text);
    padding: 24px;
    line-height: 1.6;
  }

  .header {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    border-bottom: 1px solid var(--border);
    padding-bottom: 16px;
    margin-bottom: 24px;
  }

  .header h1 {
    font-size: 18px;
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--accent);
  }

  .header .time {
    font-size: 12px;
    color: var(--text-dim);
  }

  .stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 12px;
    margin-bottom: 32px;
  }

  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
  }

  .stat-card .label {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-dim);
    margin-bottom: 4px;
  }

  .stat-card .value {
    font-size: 22px;
    font-weight: 600;
  }

  .stat-card .value.green { color: var(--accent); }
  .stat-card .value.red { color: var(--red); }
  .stat-card .value.yellow { color: var(--yellow); }

  h2 {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: var(--text-dim);
    margin-bottom: 12px;
    margin-top: 32px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
  }

  th {
    text-align: left;
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    color: var(--text-dim);
    font-weight: 400;
    text-transform: uppercase;
    font-size: 10px;
    letter-spacing: 1px;
  }

  td {
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    max-width: 400px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  tr:hover { background: rgba(34, 214, 138, 0.03); }

  .tag {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
  }
  .tag-buy { background: rgba(34, 214, 138, 0.15); color: var(--accent); }
  .tag-sell { background: rgba(239, 68, 68, 0.15); color: var(--red); }
  .tag-hold { background: rgba(59, 130, 246, 0.15); color: var(--blue); }
  .tag-error { background: rgba(234, 179, 8, 0.15); color: var(--yellow); }
  .tag-scan { background: rgba(102, 102, 128, 0.15); color: var(--text-dim); }
</style>
</head>
<body>

<div class="header">
  <h1>◆ Polymarket Bot</h1>
  <div class="time">{{ now }} &nbsp;|&nbsp; 自动刷新 60s</div>
</div>

<div class="stats">
  <div class="stat-card">
    <div class="label">今日已花费</div>
    <div class="value {{ 'red' if daily_spend > 4 else 'green' }}">${{ "%.2f"|format(daily_spend) }}</div>
  </div>
  <div class="stat-card">
    <div class="label">今日预算剩余</div>
    <div class="value">${{ "%.2f"|format(5.00 - daily_spend) }}</div>
  </div>
  <div class="stat-card">
    <div class="label">总事件数</div>
    <div class="value">{{ total_events }}</div>
  </div>
  <div class="stat-card">
    <div class="label">今日交易</div>
    <div class="value">{{ today_trades }}</div>
  </div>
</div>

<h2>最近事件日志</h2>
<table>
  <thead>
    <tr><th>时间</th><th>类型</th><th>标的</th><th>详情</th></tr>
  </thead>
  <tbody>
    {% for e in events %}
    <tr>
      <td>{{ e.timestamp[:16] }}</td>
      <td><span class="tag tag-{{ e.event_type }}">{{ e.event_type }}</span></td>
      <td>{{ e.market_slug or '-' }}</td>
      <td title="{{ e.detail }}">{{ e.detail[:80] if e.detail else '-' }}</td>
    </tr>
    {% endfor %}
    {% if not events %}
    <tr><td colspan="4" style="color:var(--text-dim);text-align:center;padding:32px">暂无数据 — 机器人启动后将自动记录</td></tr>
    {% endif %}
  </tbody>
</table>

</body>
</html>
"""


def create_app():
    app = Flask(__name__)

    @app.route("/")
    def index():
        events = get_recent_events(50)
        daily_spend = get_daily_spend()
        today = datetime.now().strftime("%Y-%m-%d")

        conn = get_conn()
        total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        today_trades = conn.execute(
            "SELECT COUNT(*) FROM events WHERE event_type IN ('buy','sell') AND timestamp LIKE ?",
            (today + "%",)
        ).fetchone()[0]
        conn.close()

        return render_template_string(
            DASHBOARD_HTML,
            events=events,
            daily_spend=daily_spend,
            total_events=total,
            today_trades=today_trades,
            now=datetime.now().strftime("%Y-%m-%d %H:%M"),
        )

    return app
