"""
Module A — 市场扫描器
拉取Polymarket候选标的 + 组装Gemini Deep Research prompt
"""

import requests
import logging
from datetime import datetime, timedelta

log = logging.getLogger("scanner")

# Polymarket API endpoints
GAMMA_API = "https://gamma-api.polymarket.com"


class MarketScanner:

    def fetch_candidates(self,
                         max_price=0.15,
                         min_price=0.01,
                         min_volume_24h=5000,
                         min_days_to_expiry=7,
                         limit=20):
        """
        从Polymarket拉取符合筛选条件的低概率市场
        """
        try:
            # Gamma API: 获取活跃市场
            resp = requests.get(f"{GAMMA_API}/markets", params={
                "active": "true",
                "closed": "false",
                "limit": 200,
                "order": "volume24hr",
                "ascending": "false"
            }, timeout=30)
            resp.raise_for_status()
            markets = resp.json()

            candidates = []
            now = datetime.utcnow()

            for m in markets:
                try:
                    # 解析关键字段
                    end_date_str = m.get("endDate") or m.get("end_date_iso", "")
                    if not end_date_str:
                        continue
                    end_date = datetime.fromisoformat(end_date_str.replace("Z", ""))
                    days_left = (end_date - now).days

                    if days_left < min_days_to_expiry:
                        continue

                    volume_24h = float(m.get("volume24hr", 0) or 0)
                    if volume_24h < min_volume_24h:
                        continue

                    # 检查每个token的价格
                    # Polymarket市场通常有 YES/NO 两个outcome
                    outcomes = m.get("outcomePrices", "")
                    if isinstance(outcomes, str) and outcomes:
                        # 格式通常是 "[0.95, 0.05]" 或类似
                        import json
                        prices = json.loads(outcomes)
                    elif isinstance(outcomes, list):
                        prices = outcomes
                    else:
                        continue

                    for i, price_str in enumerate(prices):
                        price = float(price_str)
                        if min_price <= price <= max_price:
                            side = "YES" if i == 0 else "NO"
                            slug = m.get("slug", m.get("condition_id", "unknown"))
                            candidates.append({
                                "market_slug": slug,
                                "question": m.get("question", "N/A"),
                                "side": side,
                                "current_price": price,
                                "volume_24h": volume_24h,
                                "days_left": days_left,
                                "end_date": end_date_str,
                                "condition_id": m.get("conditionId", m.get("condition_id", "")),
                                "tokens": m.get("clobTokenIds", ""),
                            })

                except (ValueError, KeyError, TypeError) as e:
                    continue

            # 按24h交易量排序，取top N
            candidates.sort(key=lambda x: x["volume_24h"], reverse=True)
            log.info(f"扫描完成: {len(candidates)} 个候选标的 (从 {len(markets)} 个市场中筛选)")
            return candidates[:limit]

        except Exception as e:
            log.exception(f"市场扫描失败: {e}")
            return []

    def build_prompt(self, candidates, positions, balance, max_picks=1):
        """
        组装发给Gemini Deep Research的完整prompt
        """
        # ── 系统角色 ──
        prompt = """【系统角色设定】
你现在是一个顶级的 Polymarket 预测市场量化研究员与"超级预测者 (Superforecaster)"。
核心任务：从以下候选市场中，找出被大众情绪严重低估的"小概率长尾错配事件"。
我的账户资金极小，目标是通过极其分散的微小下注，利用情绪波动差价获利（不一定持有到结算）。

【硬性规则】
1. 赔率空间必须 > 3倍（即 AI真实概率 / 市场价格 > 3）
2. 只推荐你有高度信心认为市场严重错误定价的标的
3. 最多只推荐 """ + str(max_picks) + """ 个标的
4. 必须进行Deep Research搜索最新新闻和数据

【第一阶段：信息扫描】
- 搜索每个候选标的的最新权威信息（官方数据、SEC文件、顶级媒体）
- 寻找历史基准率 (Base Rate)

【第二阶段：辩论与校准】
- 基于基准率和最新催化剂，给出数学推演
- 进行"魔鬼代言人"反向压力测试
- 输出独立于市场价格的"真实发生概率"

"""

        # ── 候选市场数据 ──
        prompt += "【候选市场列表】\n"
        for i, c in enumerate(candidates[:10], 1):  # 最多给10个候选
            prompt += f"""
--- 候选 {i} ---
问题: {c['question']}
方向: 买入 {c['side']}
当前市场价格: ${c['current_price']:.3f} ({c['current_price']*100:.1f}%)
24h交易量: ${c['volume_24h']:,.0f}
距到期: {c['days_left']}天
市场slug: {c['market_slug']}
"""

        # ── 当前持仓 ──
        prompt += "\n【我的当前持仓】\n"
        if positions:
            for p in positions:
                prompt += f"- {p.get('market_slug', 'unknown')}: {p.get('side', '?')} @ ${p.get('avg_price', 0):.3f} | 当前价=${p.get('current_price', 0):.3f}\n"
        else:
            prompt += "- 无持仓\n"

        prompt += f"\n当前账户余额: ${balance:.2f}\n"

        # ── 强制输出格式 ──
        prompt += """
【输出格式 — 极其重要，必须严格遵守】
在你的分析结束后，你必须在回复的最后输出一个JSON代码块。格式如下：

```json
{
  "new_bets": [
    {
      "market_slug": "这里填market slug",
      "question": "这里填市场问题",
      "side": "YES 或 NO",
      "market_price": 0.03,
      "ai_true_prob": 0.12,
      "ai_confidence": "low/medium/high",
      "reasoning_summary": "50字以内的核心理由"
    }
  ],
  "position_actions": [
    {
      "market_slug": "已持有的market slug",
      "action": "hold 或 sell 或 add",
      "reasoning_summary": "50字以内的理由"
    }
  ]
}
```

如果没有值得推荐的标的，new_bets 留空数组 []。
必须输出这个JSON代码块，否则我的自动化系统无法解析。
"""
        return prompt

    def build_position_review_prompt(self, position_info: dict) -> str:
        """为持仓复审构建prompt"""
        alert_type = "盈利" if position_info["type"] == "profit" else "亏损"
        prompt = f"""【紧急持仓复审请求】

我持有以下Polymarket市场仓位，目前{alert_type} {abs(position_info['pct_change']):.1f}%，需要你进行Deep Research判断是否应该卖出。

市场: {position_info['question']}
我的方向: {position_info['side']}
买入价: ${position_info['avg_price']:.3f}
当前价: ${position_info['current_price']:.3f}
变动: {position_info['pct_change']:+.1f}%
距到期: {position_info.get('days_left', '未知')}天

请搜索该事件的最新新闻和数据，评估：
1. 基本面是否发生了根本变化？
2. 当前价格是否已经反映了所有新信息？
3. 是否还有进一步的上涨/下跌空间？

然后在回复最后输出JSON：

```json
{{
  "action": "sell 或 hold 或 add",
  "ai_true_prob": 0.xx,
  "reasoning": "100字以内的核心判断理由"
}}
```
"""
        return prompt
