"""
Module C — 报告解析器
从Gemini自然语言输出中提取结构化交易指令
双保险: 先尝试JSON代码块，再尝试关键词匹配
"""

import json
import re
import logging

log = logging.getLogger("parser")


class ReportParser:

    def parse(self, raw_text: str) -> dict:
        """
        解析Gemini Deep Research输出
        返回: {"new_bets": [...], "position_actions": [...]} 或 None
        """
        if not raw_text:
            return None

        # ── 方法1: 提取 ```json 代码块 ──
        result = self._try_json_block(raw_text)
        if result:
            log.info("✅ JSON代码块解析成功")
            return self._validate_and_clean(result)

        # ── 方法2: 提取裸JSON（没有代码块标记） ──
        result = self._try_bare_json(raw_text)
        if result:
            log.info("✅ 裸JSON解析成功")
            return self._validate_and_clean(result)

        # ── 方法3: 关键词匹配（兜底） ──
        result = self._try_keyword_extraction(raw_text)
        if result:
            log.info("⚠️ 降级为关键词匹配解析")
            return self._validate_and_clean(result)

        log.error("❌ 所有解析方法均失败，本轮作废")
        return None

    def parse_position_action(self, raw_text: str) -> dict:
        """
        解析持仓复审的响应
        返回: {"action": "sell/hold/add", "ai_true_prob": float, "reasoning": str}
        """
        default = {"action": "hold", "reasoning": "解析失败，默认持有"}

        if not raw_text:
            return default

        # 尝试提取JSON
        result = self._try_json_block(raw_text) or self._try_bare_json(raw_text)
        if result and "action" in result:
            action = result["action"].lower().strip()
            if action in ("sell", "hold", "add"):
                return {
                    "action": action,
                    "ai_true_prob": float(result.get("ai_true_prob", 0)),
                    "reasoning": result.get("reasoning", "无")
                }

        # 关键词兜底
        text_lower = raw_text.lower()
        if any(w in text_lower for w in ["卖出", "sell", "平仓", "止损", "离场"]):
            return {"action": "sell", "reasoning": "关键词匹配: 文本建议卖出"}
        if any(w in text_lower for w in ["加仓", "add", "double", "加注"]):
            return {"action": "add", "reasoning": "关键词匹配: 文本建议加仓"}

        return default

    def _try_json_block(self, text: str) -> dict:
        """尝试提取 ```json ... ``` 代码块"""
        patterns = [
            r'```json\s*\n?(.*?)\n?\s*```',
            r'```JSON\s*\n?(.*?)\n?\s*```',
            r'```\s*\n?(\{.*?\})\n?\s*```',
        ]
        for pattern in patterns:
            matches = re.findall(pattern, text, re.DOTALL)
            for match in matches:
                try:
                    return json.loads(match.strip())
                except json.JSONDecodeError:
                    continue
        return None

    def _try_bare_json(self, text: str) -> dict:
        """尝试找到最大的 {...} JSON对象"""
        # 从后往前找（JSON通常在末尾）
        brace_depth = 0
        json_end = -1
        json_start = -1

        for i in range(len(text) - 1, -1, -1):
            if text[i] == '}':
                if json_end == -1:
                    json_end = i
                brace_depth += 1
            elif text[i] == '{':
                brace_depth -= 1
                if brace_depth == 0 and json_end != -1:
                    json_start = i
                    break

        if json_start != -1 and json_end != -1:
            try:
                candidate = text[json_start:json_end + 1]
                return json.loads(candidate)
            except json.JSONDecodeError:
                pass

        return None

    def _try_keyword_extraction(self, text: str) -> dict:
        """
        兜底方案：用正则从自然语言中提取关键信息
        非常粗糙，只在前两种方法都失败时使用
        """
        bets = []

        # 尝试匹配常见模式
        # 例如: "市场slug: xxx" "真实概率: 12%" "建议买入 NO"
        slug_match = re.search(r'(?:slug|标的|market)[:\s]*["\']?([a-z0-9-]+)["\']?', text, re.I)
        prob_match = re.search(r'(?:真实概率|true.?prob|ai.?prob)[:\s]*(\d+\.?\d*)%?', text, re.I)
        price_match = re.search(r'(?:市场.?价|market.?price|定价)[:\s]*\$?(\d+\.?\d*)', text, re.I)
        side_match = re.search(r'\b(YES|NO)\b', text)

        if slug_match and prob_match:
            prob_val = float(prob_match.group(1))
            if prob_val > 1:
                prob_val /= 100  # 12% -> 0.12

            price_val = float(price_match.group(1)) if price_match else 0.03
            if price_val > 1:
                price_val /= 100

            bets.append({
                "market_slug": slug_match.group(1),
                "side": side_match.group(1) if side_match else "NO",
                "market_price": price_val,
                "ai_true_prob": prob_val,
                "ai_confidence": "low",  # 关键词匹配置信度低
                "reasoning_summary": "关键词匹配提取（非JSON解析）"
            })

        if bets:
            return {"new_bets": bets, "position_actions": []}

        return None

    def _validate_and_clean(self, data: dict) -> dict:
        """验证并清理解析结果"""
        cleaned = {"new_bets": [], "position_actions": []}

        for bet in data.get("new_bets", []):
            try:
                price = float(bet.get("market_price", 0))
                prob = float(bet.get("ai_true_prob", 0))

                # 如果是百分比形式 (12 而不是 0.12)
                if prob > 1:
                    prob /= 100
                if price > 1:
                    price /= 100

                # 基本合理性检查
                if not (0.001 <= price <= 0.20):
                    log.warning(f"价格 {price} 超出范围，跳过")
                    continue
                if not (0.01 <= prob <= 0.90):
                    log.warning(f"概率 {prob} 超出范围，跳过")
                    continue
                if prob / price < 2.5:
                    log.warning(f"边际不足 (p/m = {prob/price:.1f} < 2.5)，跳过")
                    continue

                cleaned["new_bets"].append({
                    "market_slug": str(bet.get("market_slug", "")),
                    "question": str(bet.get("question", "")),
                    "side": str(bet.get("side", "NO")).upper(),
                    "market_price": price,
                    "ai_true_prob": prob,
                    "ai_confidence": str(bet.get("ai_confidence", "medium")),
                    "reasoning_summary": str(bet.get("reasoning_summary", ""))[:200],
                })
            except (ValueError, TypeError) as e:
                log.warning(f"清理bet数据出错: {e}")
                continue

        for action in data.get("position_actions", []):
            try:
                act = str(action.get("action", "hold")).lower()
                if act not in ("sell", "hold", "add"):
                    act = "hold"
                cleaned["position_actions"].append({
                    "market_slug": str(action.get("market_slug", "")),
                    "action": act,
                    "reasoning_summary": str(action.get("reasoning_summary", ""))[:200],
                })
            except:
                continue

        return cleaned
