"""
持仓监控器 — 每5分钟检查盈亏，触发AI复审
"""

import logging
from modules.executor import Executor
from modules.market_scanner import MarketScanner

log = logging.getLogger("monitor")


class PositionMonitor:
    def __init__(self):
        self.executor = Executor()
        self.scanner = MarketScanner()

    def check_all(self, profit_trigger: float = 200, loss_trigger: float = 50) -> list:
        """
        检查所有持仓，返回需要AI复审的告警列表
        profit_trigger: 盈利百分比阈值 (200 = 200%)
        loss_trigger: 亏损百分比阈值 (50 = 50%)
        """
        positions = self.executor.get_positions()
        if not positions:
            return []

        alerts = []
        for pos in positions:
            avg_price = pos.get("avg_price", 0)
            current_price = pos.get("current_price", 0)

            if avg_price <= 0:
                continue

            pct_change = ((current_price - avg_price) / avg_price) * 100

            if pct_change >= profit_trigger:
                alerts.append({
                    **pos,
                    "type": "profit",
                    "pct_change": pct_change,
                })
                log.info(f"🟢 盈利告警: {pos['market_slug']} +{pct_change:.1f}%")

            elif pct_change <= -loss_trigger:
                alerts.append({
                    **pos,
                    "type": "loss",
                    "pct_change": pct_change,
                })
                log.info(f"🔴 亏损告警: {pos['market_slug']} {pct_change:.1f}%")

        return alerts

    def build_review_prompt(self, alert: dict) -> str:
        """为触发告警的持仓构建AI复审prompt"""
        return self.scanner.build_position_review_prompt(alert)
