"""
Module D (Part 1) — 风控引擎
1/10 凯利 + 绝对硬性封顶 + 每日预算控制
"""

import logging
from datetime import datetime
from modules.db import get_daily_spend, add_daily_spend

log = logging.getLogger("risk")


class RiskEngine:
    def __init__(self,
                 daily_budget: float = 5.00,
                 max_bet_usd: float = 1.00,
                 min_bet_usd: float = 0.50,
                 kelly_fraction: float = 0.10,   # 1/10 凯利
                 min_edge_ratio: float = 2.5):    # p/m 必须 > 2.5
        self.daily_budget = daily_budget
        self.max_bet = max_bet_usd
        self.min_bet = min_bet_usd
        self.kelly_frac = kelly_fraction
        self.min_edge = min_edge_ratio
        self._last_reset_date = datetime.now().strftime("%Y-%m-%d")

    def calculate_bet(self, balance: float, market_price: float, ai_true_prob: float) -> float:
        """
        计算下注金额
        返回: 美元金额（0 表示不下注）
        """
        p = ai_true_prob
        m = market_price

        # ── 边际检查 ──
        if m <= 0 or p <= 0:
            return 0
        if p / m < self.min_edge:
            log.info(f"边际不足: p/m = {p/m:.2f} < {self.min_edge}")
            return 0

        # ── 凯利公式 ──
        b = (1 - m) / m                    # 净赔率
        f_kelly = (b * p - (1 - p)) / b    # 标准凯利
        f_actual = f_kelly * self.kelly_frac  # 1/10 凯利

        if f_actual <= 0:
            log.info(f"凯利比例为负: f={f_actual:.4f}，不下注")
            return 0

        target = balance * f_actual

        # ── 硬性封顶 ──
        target = min(target, self.max_bet)

        # ── 最低限额检查 ──
        if target < self.min_bet:
            # 如果算出来低于平台最低限额但>0，拉平到最低限额
            # 但如果余额本身就不够最低限额，放弃
            if balance >= self.min_bet:
                target = self.min_bet
            else:
                log.warning(f"余额 ${balance:.2f} 不足最低下注 ${self.min_bet}")
                return 0

        target = round(target, 2)

        log.info(f"凯利计算: b={b:.1f} f*={f_kelly:.4f} f/10={f_actual:.4f} "
                 f"→ ${target} (余额${balance:.2f}的{target/balance*100:.1f}%)")
        return target

    def check_daily_budget(self, amount: float) -> bool:
        """检查是否超出每日预算"""
        today = datetime.now().strftime("%Y-%m-%d")
        spent = get_daily_spend(today)
        if spent + amount > self.daily_budget:
            log.warning(f"每日预算检查: 已花${spent:.2f} + 本次${amount:.2f} > 上限${self.daily_budget:.2f}")
            return False
        return True

    def record_spend(self, amount: float):
        """记录支出"""
        add_daily_spend(amount)

    def reset_daily_budget_if_needed(self):
        """如果跨天了，自动重置"""
        today = datetime.now().strftime("%Y-%m-%d")
        if today != self._last_reset_date:
            self._last_reset_date = today
            log.info(f"新的一天: {today}，每日预算重置为 ${self.daily_budget}")
