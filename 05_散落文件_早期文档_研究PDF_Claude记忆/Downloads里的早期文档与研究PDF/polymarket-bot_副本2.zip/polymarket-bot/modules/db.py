"""SQLite 数据库 — 交易日志与状态持久化"""

import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = "trading_bot.db"


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            event_type TEXT NOT NULL,
            market_slug TEXT,
            detail TEXT
        );
        CREATE TABLE IF NOT EXISTS daily_spend (
            date TEXT PRIMARY KEY,
            total_usd REAL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            market_slug TEXT NOT NULL,
            side TEXT NOT NULL,
            action TEXT NOT NULL,
            amount_usd REAL,
            price REAL,
            ai_true_prob REAL,
            reasoning TEXT
        );
    """)
    conn.commit()
    conn.close()


def log_event(event_type: str, market_slug: str, detail: str = ""):
    conn = get_conn()
    conn.execute(
        "INSERT INTO events (timestamp, event_type, market_slug, detail) VALUES (?, ?, ?, ?)",
        (datetime.now().isoformat(), event_type, market_slug, detail)
    )
    conn.commit()
    conn.close()


def get_daily_spend(date_str: str = None) -> float:
    if not date_str:
        date_str = datetime.now().strftime("%Y-%m-%d")
    conn = get_conn()
    row = conn.execute("SELECT total_usd FROM daily_spend WHERE date = ?", (date_str,)).fetchone()
    conn.close()
    return row["total_usd"] if row else 0.0


def add_daily_spend(amount: float, date_str: str = None):
    if not date_str:
        date_str = datetime.now().strftime("%Y-%m-%d")
    conn = get_conn()
    conn.execute("""
        INSERT INTO daily_spend (date, total_usd) VALUES (?, ?)
        ON CONFLICT(date) DO UPDATE SET total_usd = total_usd + ?
    """, (date_str, amount, amount))
    conn.commit()
    conn.close()


def get_recent_events(limit=50):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def log_trade(market_slug, side, action, amount, price, ai_prob, reasoning):
    conn = get_conn()
    conn.execute(
        "INSERT INTO trades (timestamp, market_slug, side, action, amount_usd, price, ai_true_prob, reasoning) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (datetime.now().isoformat(), market_slug, side, action, amount, price, ai_prob, reasoning)
    )
    conn.commit()
    conn.close()
