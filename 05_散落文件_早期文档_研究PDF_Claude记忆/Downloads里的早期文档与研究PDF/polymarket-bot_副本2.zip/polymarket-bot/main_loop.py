#!/usr/bin/env python3
"""
Polymarket 全自动交易机器人 — 主调度器
每5小时: 扫描市场 → Gemini Deep Research → 解析 → 下注(最多1个标的)
每5分钟: 监控持仓 → 触发止盈/止损AI复审
Flask dashboard: 独立线程运行
"""

import time
import threading
import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

# ── 项目模块 ──
from modules.market_scanner import MarketScanner
from modules.gemini_driver import GeminiDriver
from modules.report_parser import ReportParser
from modules.risk_engine import RiskEngine
from modules.executor import Executor
from modules.position_monitor import PositionMonitor
from modules.db import init_db, log_event

# ── 配置 ──
SCAN_INTERVAL_HOURS = 5          # 每5小时跑一次AI扫描
MONITOR_INTERVAL_MIN = 5         # 每5分钟监控一次持仓
DAILY_BUDGET_USD = 5.00          # 每日预算上限
MAX_RECOMMENDATIONS = 1          # 每轮AI最多推荐1个标的
PROFIT_TRIGGER_PCT = 200         # 盈利超200%触发AI复审
LOSS_TRIGGER_PCT = 50            # 亏损超50%触发AI复审
CHROME_USER_DATA = str(Path.home() / "Library/Application Support/Google/Chrome")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("main")


class TradingBot:
    def __init__(self):
        init_db()
        self.scanner = MarketScanner()
        self.gemini = GeminiDriver(CHROME_USER_DATA)
        self.parser = ReportParser()
        self.risk = RiskEngine(daily_budget=DAILY_BUDGET_USD)
        self.executor = Executor()
        self.monitor = PositionMonitor()
        self.last_scan_time = None

    # ═══════════════════════════════════════════
    #  核心循环 A: 每5小时 — 扫描+AI分析+下注
    # ═══════════════════════════════════════════
    def scan_and_trade(self):
        log.info("═══ 开始第A轮: 市场扫描 + AI分析 ═══")
        try:
            # Step 1: 拉取候选市场
            candidates = self.scanner.fetch_candidates()
            if not candidates:
                log.warning("未找到符合条件的候选市场，跳过本轮")
                return

            # Step 2: 获取当前持仓和余额
            positions = self.executor.get_positions()
            balance = self.executor.get_balance()

            # Step 3: 组装prompt
            prompt = self.scanner.build_prompt(
                candidates=candidates,
                positions=positions,
                balance=balance,
                max_picks=MAX_RECOMMENDATIONS
            )

            # Step 4: 发送给Gemini Deep Research
            log.info("正在调用 Gemini Deep Research（预计3-10分钟）...")
            raw_report = self.gemini.run_deep_research(prompt)
            if not raw_report:
                log.error("Gemini 未返回结果，跳过本轮")
                return

            # 保存原始报告
            report_path = f"reports/report_{datetime.now():%Y%m%d_%H%M}.txt"
            Path("reports").mkdir(exist_ok=True)
            Path(report_path).write_text(raw_report, encoding="utf-8")
            log.info(f"报告已保存: {report_path}")

            # Step 5: 解析报告
            parsed = self.parser.parse(raw_report)
            if not parsed or not parsed.get("new_bets"):
                log.info("AI本轮无推荐标的")
                log_event("scan", "no_recommendation", "AI未给出有效推荐")
                return

            # Step 6: 风控 + 下注
            for bet in parsed["new_bets"][:MAX_RECOMMENDATIONS]:
                amount = self.risk.calculate_bet(
                    balance=balance,
                    market_price=bet["market_price"],
                    ai_true_prob=bet["ai_true_prob"]
                )
                if amount <= 0:
                    log.info(f"风控拦截: {bet['market_slug']} 金额不足或边际不够")
                    continue

                if not self.risk.check_daily_budget(amount):
                    log.warning(f"已达每日预算上限 ${DAILY_BUDGET_USD}")
                    break

                log.info(f"下注: {bet['market_slug']} | {bet['side']} | ${amount}")
                success = self.executor.place_bet(
                    market_slug=bet["market_slug"],
                    side=bet["side"],
                    amount=amount,
                    price=bet["market_price"]
                )
                if success:
                    self.risk.record_spend(amount)
                    log_event("buy", bet["market_slug"],
                              f"${amount} | side={bet['side']} | "
                              f"p={bet['ai_true_prob']} m={bet['market_price']} | "
                              f"理由: {bet.get('reasoning_summary', 'N/A')}")

            self.last_scan_time = datetime.now()

        except Exception as e:
            log.exception(f"扫描交易轮出错: {e}")
            log_event("error", "scan_and_trade", str(e))

    # ═══════════════════════════════════════════
    #  核心循环 B: 每5分钟 — 持仓监控
    # ═══════════════════════════════════════════
    def check_positions(self):
        try:
            alerts = self.monitor.check_all(
                profit_trigger=PROFIT_TRIGGER_PCT,
                loss_trigger=LOSS_TRIGGER_PCT
            )
            if not alerts:
                return

            for alert in alerts:
                log.info(f"持仓告警: {alert['market_slug']} | "
                         f"类型={alert['type']} | 变动={alert['pct_change']:.1f}%")

                # 组装持仓复审prompt
                prompt = self.monitor.build_review_prompt(alert)

                log.info("触发AI复审（Gemini Deep Research）...")
                raw_response = self.gemini.run_deep_research(prompt)
                if not raw_response:
                    log.warning("Gemini复审无响应，默认持有")
                    continue

                action = self.parser.parse_position_action(raw_response)
                log.info(f"AI建议: {action['action']} | 理由: {action.get('reasoning', 'N/A')}")

                if action["action"] == "sell":
                    self.executor.close_position(alert["market_slug"])
                    log_event("sell", alert["market_slug"],
                              f"AI复审卖出 | {alert['type']} {alert['pct_change']:.1f}% | "
                              f"理由: {action.get('reasoning', 'N/A')}")
                elif action["action"] == "add":
                    # 加仓也要过风控
                    balance = self.executor.get_balance()
                    add_amount = self.risk.calculate_bet(
                        balance=balance,
                        market_price=alert["current_price"],
                        ai_true_prob=action.get("ai_true_prob", alert["current_price"] * 3)
                    )
                    if add_amount > 0 and self.risk.check_daily_budget(add_amount):
                        self.executor.place_bet(
                            market_slug=alert["market_slug"],
                            side=alert["side"],
                            amount=add_amount,
                            price=alert["current_price"]
                        )
                        self.risk.record_spend(add_amount)
                        log_event("add", alert["market_slug"],
                                  f"AI建议加仓 ${add_amount}")
                else:
                    log_event("hold", alert["market_slug"],
                              f"AI建议持有 | 理由: {action.get('reasoning', 'N/A')}")

        except Exception as e:
            log.exception(f"持仓监控出错: {e}")
            log_event("error", "check_positions", str(e))

    # ═══════════════════════════════════════════
    #  主运行
    # ═══════════════════════════════════════════
    def run(self):
        log.info("🚀 Polymarket 交易机器人启动")
        log.info(f"   扫描间隔: {SCAN_INTERVAL_HOURS}h | 监控间隔: {MONITOR_INTERVAL_MIN}min")
        log.info(f"   每日预算: ${DAILY_BUDGET_USD} | 每轮最多推荐: {MAX_RECOMMENDATIONS}个")

        # 启动Flask dashboard (独立线程)
        from modules.dashboard import create_app
        app = create_app()
        flask_thread = threading.Thread(
            target=lambda: app.run(host="0.0.0.0", port=5050, debug=False),
            daemon=True
        )
        flask_thread.start()
        log.info("📊 Dashboard 已启动: http://localhost:5050")

        # 首次立即运行一轮扫描
        self.scan_and_trade()

        scan_interval = SCAN_INTERVAL_HOURS * 3600
        monitor_interval = MONITOR_INTERVAL_MIN * 60
        last_scan = time.time()
        last_monitor = time.time()

        while True:
            now = time.time()

            # 每5小时: 扫描+交易
            if now - last_scan >= scan_interval:
                self.risk.reset_daily_budget_if_needed()
                self.scan_and_trade()
                last_scan = now

            # 每5分钟: 持仓监控
            if now - last_monitor >= monitor_interval:
                self.check_positions()
                last_monitor = now

            time.sleep(30)  # 主循环30秒检查一次


if __name__ == "__main__":
    bot = TradingBot()
    bot.run()
